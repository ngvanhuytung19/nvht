# RD Week 4 Final Project

Responsive Design final project submission.

## Files
- `index.html` — accessible responsive gallery with replacement content and alt text.
- `style.css` — mobile-first CSS and four required media queries.
- `images/` — nine replacement SVG images.

## Required behavior
- Mobile: one-column grid with 10px gap.
- Tablet at 772px: two columns, circular images, last figure spans both columns.
- Large screens at 992px: every third figure spans both columns, image border-radius removed, no max-width.
- Reduced motion: scrolling behavior is disabled/reduced.
- Dark mode: dark figure backgrounds, light text, black borders.
